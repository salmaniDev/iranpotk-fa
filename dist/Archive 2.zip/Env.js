window._env_ = {
    'ApiUrl': 'https://iranpotk.com/templates/iranpotk/ajax.php?',
    'SiteUrl': 'https://iranpotk.com'
}