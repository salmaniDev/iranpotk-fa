$(".about-us #cerrtificate .slider").slick({
    cssEase: 'linear',
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    dots: false,
    infinite: true,
    fade: true,
    autoplay: true,
    autoplaySpeed: 2000,

    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                rtl: true,
                fade:false
            }
        },
    ]
});

// $(".about-us #cerrtificate .slider").slick({
//     slidesToShow: 3,
//     slidesToScroll: 1,
//     arrows: false,
//     dots: false,
//     centerMode: true,
//     variableWidth: true,
//     infinite: true,
//     focusOnSelect: true,
//     cssEase: 'linear',
//     touchMove: true,
// });