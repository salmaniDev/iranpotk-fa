window._env_ = {
    'ApiUrl': 'https://demo2.iranpotk.com/templates/iranpotk/ajax.php?',
    'SiteUrl': 'https://demo2.iranpotk.com'
}