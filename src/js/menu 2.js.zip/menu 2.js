window.addEventListener('load', async () => {
    const navbar = window.iranPotkVar.navbar;
    const burgger = window.iranPotkVar.burgger;
    const productMenu = document.querySelector("#productMenu");
    const overlay = window.iranPotkVar.overlay;
    const showMenuBtn = document.querySelector("#showMenuBtn");
    const listsInfo = document.querySelector('.lists_info');
    const navbarMenuList = document.querySelector("#navbarMenuList");
    const navbarMenuListHead = document.querySelector("#navbarMenuListHead");
    const mediaQuery = window.matchMedia('(min-width: 991px)');

    const ldsRing = `<div class="lds-ring"><div></div><div></div><div></div></div>`

    showMenuBtn.addEventListener('click', () => {
        const width = navbar.offsetHeight;
        if (!navbar.classList.contains('scroll')) {
            productMenu.style.transform = `translate(50%,${width + "px"})`;
        } else {
            productMenu.style.transform = "translate(50%,67px)";
        }
        productMenu.classList.toggle('active');
        showMenuBtn.classList.toggle('active');
        overlay.classList.toggle('active');
        document.body.classList.toggle('disable');
    })

    let mainMenu = await fetch('../json/mainMenu.json').then((response) => { return response.json(); }).then((data) => { return data.mainMenu });
    if (mainMenu.length === 0) {
        navbarMenuList.innerHTML = ldsRing
    } else {
        for (let i = 0; i < mainMenu.length; i++) {
            const li = document.createElement('li');
            li.innerHTML = mainMenu[i].title;
            navbarMenuList.append(li)

            li.addEventListener('click', async () => {
                const navbarMenuListItem = navbarMenuList.querySelectorAll('li');
                //console.log(mainMenu[i].id);
                navbarMenuListItem.forEach(item => {
                    item.classList.remove('active')
                })
                li.classList.add('active');
                navbarMenuListHead.innerHTML = "";

                let subMenu = await fetch('../json/submenu.json&s_id=' + mainMenu[i].id).then((response) => { return response.json(); }).then((data) => { return data.subMenu });
                for (let i = 0; i < subMenu.length; i++) {
                    const li = document.createElement('li');
                    li.innerHTML = subMenu[i].title;
                    navbarMenuListHead.append(li)

                    li.addEventListener('click', async () => {
                        const navbarMenuListHeadItem = navbarMenuListHead.querySelectorAll('li')
                        navbarMenuListHeadItem.forEach(item => {
                            item.classList.remove('active')
                        })
                        li.classList.add('active');
                        let categoryProduct = await fetch('../json/categoryProduct.json&sb_id=' + subMenu[i].id).then((response) => { return response.json(); }).then((data) => { return data });
                        renderProductMenu(categoryProduct)
                    })
                    if (i == 0) {
                        li.click();
                        li.classList.add('active')
                    }
                    listsInfo.classList.add('active');

                }
            })
            if (i == 0 && mediaQuery.matches) {
                li.click();
                li.classList.add('active')
            }
        }
    }

    function renderProductMenu(data) {
        document.getElementById('lists_info').innerHTML = ''
        const desc = document.createElement('span');
        desc.classList.add('desc');
        desc.innerText = data.desc;
        const linkItem = document.createElement('a');
        linkItem.setAttribute('class', "link btn_dark");
        linkItem.href = data.permalink;
        linkItem.innerText = "مشاهده همه محصولات"
        const icon = document.createElement('i')
        icon.setAttribute('class', "icon icon-arrowL")
        linkItem.append(icon)
        let listItems = document.createElement('div');
        listItems.classList.add('list_items');
        data.category.forEach(item => {
            const a = document.createElement('a');
            a.classList.add('item');
            a.href = item.permalink;
            const img = document.createElement('img');
            img.src = item.image.src;
            img.classList.add('image');
            img.alt = item.title
            const h3 = document.createElement('h3');
            h3.innerText = item.title;
            h3.classList.add('title');
            a.append(img, h3);
            listItems.append(a);
        });
        document.getElementById('lists_info').append(desc, listItems, linkItem)
    }
})