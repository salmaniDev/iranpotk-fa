window.addEventListener('load', () => {
    window.iranPotkVar = {
        "navbar": document.querySelector('.navbar'),
        "burgger": document.querySelector('.burgger'),
        "overlay": document.querySelector('.overlay'),
    }
})