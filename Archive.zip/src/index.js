import "../dist/Env";
import "./main.scss";
import "./js/API/Category";
import "./js/API/productProperty";
import "./js/publicVar";
import "./js/app";
import "./js/scrollContainer";
// import "./js/home";
import "./js/menu"; 
import "./js/navbar";
import "./js/tabbar";
import "./js/faq";
import "./js/product-list";
import "./js/numberSpinnet";
import "./js/payment";
import "./js/stickyBox";
import "./js/filter-menu";
import "./js/calendar";


// dashbord 
import './js/Dahsbord/orders'
import './js/Dahsbord/comments'